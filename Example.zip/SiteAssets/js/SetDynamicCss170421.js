/*
	This is used in the Our Services web page

	Sets the keyframe dynamically when the page is loaded.
	it is dynamic because the screen width needs to be set in the
	css to optimize the slide in effect.
*/

var strScreenWidth = $(window).width()/2 + "px";
var strScreenHeight= $(window).height()/2 + "px";
var style = document.createElement('style');
style.type = 'text/css';
var keyFrames = '\
	@keyframes fadeInLeftBig\
	{\
		from \
		{\
			opacity: 0;\
			-webkit-transform: translate3d(-_HALF_SCREEN_WIDTH, 0, 0);\
			transform: translate3d(-_HALF_SCREEN_WIDTH,0px,0px);\
		}\
		to \
		{\
			opacity: 1;\
			-webkit-transform: none;\
			transform: none;\
		}\
	}\
    @keyframes fadeInDownBig \
	{ \
		from \
		{ \
			opacity: 0;\
			-webkit-transform: translate3d(0,-_HALF_SCREEN_HEIGHT, 0);\
			transform: translate3d(0,-_HALF_SCREEN_HEIGHT, 0);\
		} \
		to \
		{ \
			opacity: 1; \
			-webkit-transform: none; \
			transform: none; \
		} \
	}\
		\
		@keyframes fadeInRightBig{from {opacity: 0;-webkit-transform: translate3d(_HALF_SCREEN_WIDTH, 0, 0);transform: translate3d(_HALF_SCREEN_WIDTH,0px,0px);}to{opacity: 1;-webkit-transform: none;transform: none;}}\
		\
		@keyframes fadeOutLeftBig \
		{\
			from { opacity: 1; }\
			to { \
				opacity:0; \
				-webkit-transform: translate3d(-_HALF_SCREEN_WIDTH,0,0);\
				transform: translate3d(-_HALF_SCREEN_HEIGHT,0,0);\
			}\
		}';

        style.innerHTML = keyFrames.replace(/_HALF_SCREEN_WIDTH/g, strScreenWidth).replace(/_HALF_SCREEN_HEIGHT/g, strScreenHeight);
            document.getElementsByTagName('head')[0].appendChild(style);