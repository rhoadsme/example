	function ResetTopNavBar( obj )
	{
		// Remove the active class from all the top horizontal nav buttons
		$( "#filter button" ).removeClass('active');
			
		// add the active back to only the button selected
		obj.addClass('active');
		
		// Now enable all the buttons on the top bar
		$("#filter button").attr("disabled", false);
			
		// And disable the one "active" button we just pressed
		obj.attr("disabled", true);
	}


	function ResetSecondNavBar( obj )
	{
		// Remove the active class from the second horizontal nav bar
		$( "#filter2 option" ).removeClass('active');
		
		// add the active back to only the button selected
		obj.addClass('active');

		// I didn't disable the pressed item because the drop down
		// box looks funny with a disabled option.  Instead I 
		// used javascript/jquery to detect if the user selected
		//the same (already selected) item, and if so, it just ignores it
		
	}


	function ProcessTopHorizontalRowClick( obj )
	{
		// get the class name
		var strTopRowNavButtonClassName = obj.attr('class');
		// get the active selected second row button
		var selectedSecondRowOption = $( "#filter2 select option.active" );
		var strSecondRowNavButtonClassName = GetClassName(selectedSecondRowOption);
		// now we show/hide the large square buttons.
		HideShowSquareButtons( strTopRowNavButtonClassName, strSecondRowNavButtonClassName );
		// the following marks the top nav bar buttons active or disabled as appropriate
		ResetTopNavBar( obj );
    }
	
	function GetClassName( element )
	{
		// get the class names of the provided item
		// removes the "active" class name  and returns only one word
		// assumes there are only one or two class names, and one is "active".
		//var selectedTopRowNavButton = $( "#filter button.active" );
		
		// multiple class names should have been returned, we only care about one
		// class name.  example: "social active".  "active" indicates it was last selected,
		// we used it to select the item, so we don't care about that, we want the other
		// class name "social" in this example.
		// so below we split out all the class names and put them in a list
		
		var listOfClassNames = element.attr('class').split(' ');
		var strClassName = null;
		do 
		{
			// now we take one at a time and use the first one that is not
			// "active".  We assume there are only two class names
			strClassName = listOfClassNames.pop();
		}
		while ( strClassName == 'active' ); // keep popping, we want the other class name
		// if for some reason we don't get any class names, we will return "error"
		// which should cause nothing to be shown, which should be an obvious error
		// when we test.
		if ( strClassName == null ) strClassName = 'error';
		return strClassName;
	}


	function ProcessSecondHorizontalRowClick( obj )
	{
		// get the class name
		var strSecondRowNavButtonClassName = obj.attr('class'); 

		// if the class name contains multiple entries or "active" do nothing
		var lstClassNames = strSecondRowNavButtonClassName.split(' ');
		if ( lstClassNames.length != 1 ) return; // nothing to do, just exit
				
		// get the active selected top row button
		var selectedTopRowNavButton = $( "#filter button.active" );
		var strTopRowNavButtonClassName = GetClassName( selectedTopRowNavButton );
		HideShowSquareButtons( strTopRowNavButtonClassName, strSecondRowNavButtonClassName )
		ResetSecondNavBar( obj );
    }

function InitialLoadAnimation()
{
	$('.otherservices').hide();
	$('.questions').hide();
	$('.button').children().hide();

	SetFadeInAnimation( 750, 100, 50, 'all', 'all' );

	$('.otherservices').show();
	$('.questions').show();
}

function SetFadeInAnimation( iInitialDelay, iTilePause, iWantButtonPause, strTopRowNavButtonClassName, strSecondRowNavButtonClassName )
{
	var Count1 = iInitialDelay;
	var Count2 = iInitialDelay;
	var iCount = 0;
	var bPerformAnimation = false;

	$( ".button" ).each(function( )
	{
		bPerformAnimation = false;
		var selectedButton = $(this);
		var parent = $(this)[0].parentElement;
		if ( ( selectedButton.children(":first").hasClass(strSecondRowNavButtonClassName) || ( strSecondRowNavButtonClassName == 'all' ) )
				&& 
			   ( selectedButton.children(":first").hasClass(strTopRowNavButtonClassName) || strTopRowNavButtonClassName == 'all' ) )
		{
			var strDirection;
			if ( $(parent).hasClass('tile') )
			{
				strDirection = 'fadeInLeftBig';
				iCount = Count1;
				Count1 =  Count1 + iTilePause;
				bPerformAnimation = true;
			}
			else if ( $(parent).hasClass('wanttobutton') )
			{
				strDirection = 'fadeInRightBig';
				iCount = Count2;
				Count2 =  Count2 + iWantButtonPause;
				bPerformAnimation = true;
			}
			if ( bPerformAnimation )
			{
				parent.style.setProperty('animation-delay', (iCount) + 'ms');
				$(this).children().show();
				$(parent).removeClass(strDirection + ' animated').addClass(strDirection + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){$(this).removeClass(strDirection + ' animated');});
			}
			
		}
	});


}

	function HideShowSquareButtons( strTopRowNavButtonClassName, strSecondRowNavButtonClassName )
	{
		$('.otherservices').hide();
		$('.questions').hide();
		$('.button').children().hide();

		// and now go through each button one at a time 
		// and only show those that the filter selects
		
		SetFadeInAnimation( 0, 100, 50, strTopRowNavButtonClassName, strSecondRowNavButtonClassName );
		

		$('.otherservices').show();
		$('.questions').show();


	}

$(document).ready(function()
{
	ProcessTopHorizontalRowClick( $('#filter .all') );
	$( "#filter button" ).each(function() 
	{
		$(this).on("click",  function() 
		{ 
			ProcessTopHorizontalRowClick( $(this) );
		});
	});
	$( "#filter2 option" ).each(function() 
	{
		$(this).on("click", function()
		{ 
			ProcessSecondHorizontalRowClick( $(this) );
		});
	});
	$('.OpenAnotherModalDialog').click(function () { $('.portBox').css('display','none'); });
	InitialLoadAnimation();
    OnPageLoadCheckForDialogParameters();
});